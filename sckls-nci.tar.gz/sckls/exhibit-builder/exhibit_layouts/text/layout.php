<?php echo $text; ?>
