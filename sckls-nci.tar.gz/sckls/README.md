SCKLS Parent Theme
==================

Parent Omeka theme developed for South Central Kansas Library System (SCKLS), created by Interactive Mechanics.


Customization Features:
  *  Title
  *  Subtitle
  *  About this site
  *  Header background image
  *  Primary site color
  *  Toggle "featured" content on the homepage
  *  Footer logos (up to 3)
  *  Custom Google search via SCKLS
